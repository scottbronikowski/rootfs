/* libglade/libglademmconfig.h.  Generated from libglademmconfig.h.in by configure.  */
#ifndef _LIBGLADEMM_CONFIG_H
#define _LIBGLADEMM_CONFIG_H 1

#include "gtkmmconfig.h"

/* version numbers */
#define LIBGLADEMM_MAJOR_VERSION 2
#define LIBGLADEMM_MINOR_VERSION 6
#define LIBGLADEMM_MICRO_VERSION 7
#define LIBGLADEMM_VERSION "2.6.7"
#define LIBGLADE_VERSION_NEEDED_QUOTED "2.6.1"

#endif /* _LIBGLADEMM_CONFIG_H */

