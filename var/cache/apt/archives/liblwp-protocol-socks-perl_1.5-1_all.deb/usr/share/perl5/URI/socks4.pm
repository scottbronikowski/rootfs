package URI::socks4;
require URI::socks;

our @ISA = qw(URI::socks);

1;
