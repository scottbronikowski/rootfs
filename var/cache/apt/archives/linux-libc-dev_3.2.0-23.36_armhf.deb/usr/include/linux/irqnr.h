#ifndef _LINUX_IRQNR_H
#define _LINUX_IRQNR_H

/*
 * Generic irq_desc iterators:
 */

#endif
