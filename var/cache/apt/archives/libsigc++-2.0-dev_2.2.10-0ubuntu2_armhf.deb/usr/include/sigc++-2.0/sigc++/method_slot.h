// -*- c++ -*-
/* Do not edit! -- generated file */


#ifndef _SIGC_MACROS_METHOD_SLOTHM4_
#define _SIGC_MACROS_METHOD_SLOTHM4_
#endif /* _SIGC_MACROS_METHOD_SLOTHM4_ */
