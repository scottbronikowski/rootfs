// -*- c++ -*-
/* Do not edit! -- generated file */
#ifndef _SIGC_MACROS_RETYPEHM4_
#define _SIGC_MACROS_RETYPEHM4_
#include <sigc++/adaptors/adaptor_trait.h>
#include <sigc++/slot.h>

#endif /* _SIGC_MACROS_RETYPEHM4_ */
