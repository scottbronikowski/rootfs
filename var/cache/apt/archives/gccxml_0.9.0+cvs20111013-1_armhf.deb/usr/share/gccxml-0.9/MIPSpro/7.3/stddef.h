#ifndef __STDDEF_H_GCCXML
#define __STDDEF_H_GCCXML

#define _WCHAR_T

#include_next <stddef.h>

#endif

