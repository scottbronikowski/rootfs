#ifdef __APPLE__
# include "gccxml_apple_xmmintrin.h"
#else
# include "gccxml_gnu_xmmintrin.h"
#endif
