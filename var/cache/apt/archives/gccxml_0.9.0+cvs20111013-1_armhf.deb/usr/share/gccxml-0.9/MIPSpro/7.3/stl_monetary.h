#ifndef __SGI_STL_INTERNAL_MONETARY_H_GCCXML
#define __SGI_STL_INTERNAL_MONETARY_H_GCCXML

__STL_BEGIN_NAMESPACE

template <typename T, bool> class moneypunct;

__STL_END_NAMESPACE

#include_next <stl_monetary.h>

#endif


