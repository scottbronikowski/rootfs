/*************************************************************************/
/* OPARI Version 1.1                                                     */
/* Copyright (c) 2001-2005                                                    */
/* Forschungszentrum Juelich, Zentralinstitut fuer Angewandte Mathematik */
/*************************************************************************/

#ifndef OPARI_OMP_H
#define OPARI_OMP_H

  #ifdef _OPENMP
    #include <omp.h>
  #endif
#endif
