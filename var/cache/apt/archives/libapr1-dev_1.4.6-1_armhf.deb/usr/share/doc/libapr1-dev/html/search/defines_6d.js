var searchData=
[
  ['memmove',['memmove',['../group__apr__general.html#gad12df83f1d3a090b658adc645555ca79',1,'apr_general.h']]]
];
