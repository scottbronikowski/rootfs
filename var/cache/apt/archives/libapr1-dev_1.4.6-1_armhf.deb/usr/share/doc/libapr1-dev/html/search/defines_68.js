var searchData=
[
  ['huge_5fstring_5flen',['HUGE_STRING_LEN',['../group__apr__lib.html#ga0c9dd98f46b90b5bcd4cbf75e252d0da',1,'apr_lib.h']]]
];
