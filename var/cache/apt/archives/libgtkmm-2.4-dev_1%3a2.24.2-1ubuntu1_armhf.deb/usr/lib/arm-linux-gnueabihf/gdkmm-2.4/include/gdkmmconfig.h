/* gdk/gdkmmconfig.h.  Generated from gdkmmconfig.h.in by configure.  */
#ifndef _GDKMM_CONFIG_H
#define _GDKMM_CONFIG_H

#include <pangommconfig.h>

/* Define to omit deprecated API from gdkmm. */
/* #undef GDKMM_DISABLE_DEPRECATED */

/* Major version number of gdkmm. */
#define GDKMM_MAJOR_VERSION 2

/* Micro version number of gdkmm. */
#define GDKMM_MICRO_VERSION 2

/* Minor version number of gdkmm. */
#define GDKMM_MINOR_VERSION 24

#endif /* !_GDKMM_CONFIG_H */
